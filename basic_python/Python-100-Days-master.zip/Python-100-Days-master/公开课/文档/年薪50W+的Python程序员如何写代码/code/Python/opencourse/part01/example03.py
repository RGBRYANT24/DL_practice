values = [True] * 10
print(values)
numbers = [x for x in range(1, 11)]
print(numbers)
