a, b = 5, 10

# temp = a
# a = b
# b = a

a, b = b, a
print(f'a = {a}, b = {b}')
