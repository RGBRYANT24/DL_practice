chars = ['j', 'a', 'c', 'k', 'f', 'r', 'u', 'e', 'd']

# name = ''
# for char in chars:
#     name += char

name = ''.join(chars)
print(name)
