nums = []
for i in range(100000):
    nums.insert(0, i)
print(nums)
