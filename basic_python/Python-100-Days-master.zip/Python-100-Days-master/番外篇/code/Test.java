class Test {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, world!");
        System.exit(0);
    }
}